import os
import re

# File extensions to search
EXTENSIONS = {
    '.dart', '.py', '.kt', '.cpp', '.c', '.h',
    '.java', '.js', '.ts', '.cmake', '.make',
    'CMakeLists.txt', 'Makefile', 'Dockerfile',
    '.gradle', '.xml', '.yaml', '.yml', '.js', '.jsx',
    '.json'
}

PERSIAN_PATTERN = re.compile(r'[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+')

def should_scan(filename):
    name = os.path.basename(filename)
    _, ext = os.path.splitext(filename)
    return ext.lower() in EXTENSIONS or name in EXTENSIONS

def scan_file(filepath):
    results = []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line_num, line in enumerate(f, 1):
                if PERSIAN_PATTERN.search(line):
                    results.append((line_num, line.rstrip()))
    except Exception as e:
        print(f"  [Error reading file: {e}]")
    return results

def scan_project(root_dir):
    print(f"Scanning project: {root_dir}\n")
    print("=" * 60)

    total_matches = 0
    files_with_persian = 0

    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Skip hidden folders and common ignored dirs
        dirnames[:] = [
            d for d in dirnames
            if not d.startswith('.')
            and d not in ('build', 'node_modules', '__pycache__', '.dart_tool', '.gradle')
        ]

        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            if not should_scan(filepath):
                continue

            matches = scan_file(filepath)
            if matches:
                files_with_persian += 1
                rel_path = os.path.relpath(filepath, root_dir)
                print(f"\n📄 {rel_path}")
                print("-" * 40)
                for line_num, line in matches:
                    print(f"  Line {line_num:4d} | {line}")
                    total_matches += 1

    print("\n" + "=" * 60)
    print(f"✅ Done! Found {total_matches} Persian lines in {files_with_persian} files.")

if __name__ == "__main__":
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    scan_project(root)