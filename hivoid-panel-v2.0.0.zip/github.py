#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║           HIVOID GIT MANAGER  ·  Terminal Edition            ║
║         https://github.com/hivoid-org/hivoid-panel           ║
╚══════════════════════════════════════════════════════════════╝

A professional, menu-driven terminal application for managing
Git and GitHub operations for the hivoid-panel repository.

Usage:
    python3 github.py
"""

import os
import sys
import re
import subprocess
import shutil
import json
import stat
import getpass
import logging
from datetime import datetime

# ──────────────────────────────────────────────────────────────
# LOGGING
# ──────────────────────────────────────────────────────────────

LOG_FILE = os.path.expanduser("~/.hivoid_panel_git_manager.log")

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
    ],
)
logger = logging.getLogger("hivoid_panel")

# ──────────────────────────────────────────────────────────────
# ANSI COLOR & STYLE CODES
# ──────────────────────────────────────────────────────────────

RESET   = "\033[0m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
ITALIC  = "\033[3m"

BLACK   = "\033[30m"
RED     = "\033[31m"
GREEN   = "\033[32m"
YELLOW  = "\033[33m"
BLUE    = "\033[34m"
MAGENTA = "\033[35m"
CYAN    = "\033[36m"
WHITE   = "\033[37m"

BBLACK   = "\033[90m"
BRED     = "\033[91m"
BGREEN   = "\033[92m"
BYELLOW  = "\033[93m"
BBLUE    = "\033[94m"
BMAGENTA = "\033[95m"
BCYAN    = "\033[96m"
BWHITE   = "\033[97m"

BG_BLACK  = "\033[40m"
BG_BLUE   = "\033[44m"
BG_CYAN   = "\033[46m"
BG_WHITE  = "\033[47m"

# ──────────────────────────────────────────────────────────────
# CONSTANTS
# ──────────────────────────────────────────────────────────────

REPO_OWNER  = "hivoid-org"
REPO_NAME   = "hivoid-panel"
REPO_URL    = f"https://github.com/{REPO_OWNER}/{REPO_NAME}"
API_BASE    = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"
CONFIG_FILE = os.path.expanduser("~/.hivoid_panel_git_manager.conf")

# ──────────────────────────────────────────────────────────────
# TERMINAL UTILITIES
# ──────────────────────────────────────────────────────────────

def clear():
    os.system("clear" if os.name != "nt" else "cls")

def width():
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 80

def hr(char="─", color=BBLACK):
    print(f"{color}{char * width()}{RESET}")

def pad(text, w=None):
    w = w or width()
    return text.ljust(w)

def center(text, w=None):
    w = w or width()
    return text.center(w)

# ──────────────────────────────────────────────────────────────
# STATUS PRINTERS
# ──────────────────────────────────────────────────────────────

def ok(msg):
    print(f"  {BGREEN}✔{RESET}  {msg}")

def err(msg):
    logger.error(msg)
    print(f"  {BRED}✘{RESET}  {BOLD}{RED}{msg}{RESET}")

def warn(msg):
    logger.warning(msg)
    print(f"  {BYELLOW}⚠{RESET}  {YELLOW}{msg}{RESET}")

def info(msg):
    print(f"  {BCYAN}ℹ{RESET}  {msg}")

def step(msg):
    logger.debug(f"STEP: {msg}")
    print(f"  {BBLUE}→{RESET}  {DIM}{msg}{RESET}")

def section(title):
    print()
    print(f"  {BOLD}{BCYAN}{title}{RESET}")
    print(f"  {BBLACK}{'─' * (len(title) + 2)}{RESET}")

def blank():
    print()

# ──────────────────────────────────────────────────────────────
# HEADER / BANNER
# ──────────────────────────────────────────────────────────────

LOGO = r"""
  ██╗  ██╗██╗██╗   ██╗ ██████╗ ██╗██████╗
  ██║  ██║██║██║   ██║██╔═══██╗██║██╔══██╗
  ███████║██║██║   ██║██║   ██║██║██║  ██║
  ██╔══██║██║╚██╗ ██╔╝██║   ██║██║██║  ██║
  ██║  ██║██║ ╚████╔╝ ╚██████╔╝██║██████╔╝
  ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═════╝ ╚═╝╚═════╝
"""

def banner():
    clear()
    w = width()
    print()
    for line in LOGO.strip("\n").splitlines():
        print(f"{BCYAN}{line.center(w)}{RESET}")
    print()
    sub  = "Git & GitHub Terminal Manager  ·  hivoid-panel"
    repo = REPO_URL
    print(f"{BOLD}{BWHITE}{sub.center(w)}{RESET}")
    print(f"{DIM}{BBLACK}{repo.center(w)}{RESET}")
    blank()
    hr("═", BBLUE)

# ──────────────────────────────────────────────────────────────
# SUBPROCESS HELPERS
# ──────────────────────────────────────────────────────────────

def run(cmd, capture=True, cwd=None, env=None):
    """Run a shell command. Returns (returncode, stdout, stderr)."""
    logger.debug(f"run: {cmd}")
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=capture,
        text=True,
        cwd=cwd,
        env=env,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()

def run_live(cmd):
    """Run a command and stream output live. Returns returncode."""
    logger.debug(f"run_live: {cmd}")
    proc = subprocess.Popen(
        cmd,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    for line in proc.stdout:
        print(f"    {DIM}{BBLACK}{line.rstrip()}{RESET}")
    proc.wait()
    return proc.returncode

# ──────────────────────────────────────────────────────────────
# VALIDATION HELPERS
# ──────────────────────────────────────────────────────────────

def validate_git_installed():
    code, _, _ = run("git --version")
    if code != 0:
        err("Git is not installed or not in PATH.")
        err("Install Git from https://git-scm.com and retry.")
        sys.exit(1)

def validate_semver(tag: str) -> bool:
    """Validate vX.Y.Z format."""
    return bool(re.match(r"^v\d+\.\d+\.\d+$", tag))

def is_git_repo() -> bool:
    code, _, _ = run("git rev-parse --is-inside-work-tree")
    return code == 0

def has_uncommitted_changes() -> bool:
    code, out, _ = run("git status --porcelain")
    return bool(out)

def current_branch() -> str:
    _, out, _ = run("git rev-parse --abbrev-ref HEAD")
    return out or "unknown"

def get_remote_url() -> str:
    _, out, _ = run("git remote get-url origin")
    return out

def get_tags() -> list:
    _, out, _ = run("git tag --sort=-version:refname")
    return [t for t in out.splitlines() if t]

def gh_cli_available() -> bool:
    return shutil.which("gh") is not None

def curl_available() -> bool:
    return shutil.which("curl") is not None

# ──────────────────────────────────────────────────────────────
# PROMPT HELPERS
# ──────────────────────────────────────────────────────────────

def prompt(label, default=None):
    hint = f" [{BBLACK}{default}{RESET}]" if default else ""
    try:
        val = input(f"  {BOLD}{BCYAN}?{RESET}  {label}{hint}: ").strip()
    except (EOFError, KeyboardInterrupt):
        blank()
        return default or ""
    return val if val else (default or "")

def confirm(question, default="n") -> bool:
    opts = f"{BGREEN}Y{RESET}/{BBLACK}n{RESET}" if default == "y" else f"{BBLACK}y{RESET}/{BRED}N{RESET}"
    try:
        ans = input(f"  {BOLD}{BYELLOW}?{RESET}  {question} [{opts}]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        blank()
        return False
    if not ans:
        return default == "y"
    return ans in ("y", "yes")

def press_enter(msg="Press Enter to continue…"):
    try:
        input(f"\n  {DIM}{BBLACK}{msg}{RESET}")
    except (EOFError, KeyboardInterrupt):
        pass

def prompt_secret(label: str) -> str:
    """Password-style prompt — input is hidden."""
    try:
        val = getpass.getpass(f"  {BOLD}{BMAGENTA}🔑{RESET}  {label}: ")
    except (EOFError, KeyboardInterrupt):
        blank()
        return ""
    return val.strip()

# ──────────────────────────────────────────────────────────────
# CREDENTIALS CONFIG  (~/.hivoid_panel_git_manager.conf)
# ──────────────────────────────────────────────────────────────

def _load_config() -> dict:
    """Load saved config from disk. Returns empty dict if missing/corrupt."""
    if not os.path.isfile(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as ex:
        logger.warning(f"Failed to load config: {ex}")
        return {}

def _save_config(cfg: dict):
    """Persist config to disk with owner-only permissions (600)."""
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except Exception as ex:
        logger.error(f"Could not save config: {ex}")
        warn(f"Could not save config: {ex}")

def get_credential(key: str) -> str:
    """Return a saved credential value, or '' if not set."""
    return _load_config().get(key, "")

def set_credential(key: str, value: str):
    """Save a single credential key."""
    cfg = _load_config()
    cfg[key] = value
    _save_config(cfg)

def get_github_token() -> str:
    """
    Return GitHub token in priority order:
      1. Environment variable GITHUB_TOKEN / GH_TOKEN
      2. Saved config file
      3. Prompt user (and offer to save)
    """
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        logger.debug("GitHub token sourced from environment.")
        return token
    token = get_credential("github_token")
    if token:
        logger.debug("GitHub token sourced from config file.")
        return token
    blank()
    warn("No GitHub token found in environment or saved config.")
    info("A Personal Access Token (classic) with repo scope is required.")
    info("Generate one at: https://github.com/settings/tokens")
    blank()
    token = prompt_secret("GitHub Personal Access Token (classic)")
    if not token:
        return ""
    if confirm("Save this token for future use?", "y"):
        set_credential("github_token", token)
        ok(f"Token saved to {CONFIG_FILE}")
    return token

def get_github_username() -> str:
    """Return saved GitHub username or prompt once."""
    username = get_credential("github_username")
    if username:
        return username
    blank()
    username = prompt("GitHub username (for HTTPS authentication)")
    if username and confirm("Save this username for future use?", "y"):
        set_credential("github_username", username)
        ok(f"Username saved to {CONFIG_FILE}")
    return username

def apply_git_credentials():
    """
    Configure git to use saved credentials for HTTPS so git push/pull
    never shows a username/password prompt.
    Embeds credentials directly into the remote URL.
    """
    username = get_credential("github_username")
    token    = get_credential("github_token")
    if not username or not token:
        return

    authed_url = re.sub(
        r"https://(?:[^@]*@)?",
        f"https://{username}:{token}@",
        REPO_URL,
    )
    code, _, er = run(f'git remote set-url origin "{authed_url}"')
    if code != 0:
        logger.warning(f"apply_git_credentials: failed to set remote URL: {er}")

def manage_credentials():
    """Menu: view / update / test / clear saved credentials."""
    while True:
        banner()
        section("Credentials  ·  GitHub Authentication")

        cfg      = _load_config()
        username = cfg.get("github_username", "")
        token    = cfg.get("github_token", "")

        blank()
        info(f"Config file : {DIM}{CONFIG_FILE}{RESET}")
        blank()
        if username:
            ok(f"Username    : {BOLD}{BCYAN}{username}{RESET}")
        else:
            warn("Username    : not saved")

        if token:
            masked = token[:4] + "●" * max(4, len(token) - 8) + token[-4:]
            ok(f"Token       : {BOLD}{BBLACK}{masked}{RESET}  {DIM}(classic PAT){RESET}")
        else:
            warn("Token       : not saved")

        env_token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
        if env_token and not token:
            info(f"Env token   : {DIM}GITHUB_TOKEN / GH_TOKEN is set in environment{RESET}")

        blank()
        hr()
        blank()
        print(f"    {BGREEN}›{RESET}  {BOLD}[1]{RESET}  Save / update username & token")
        print(f"    {BGREEN}›{RESET}  {BOLD}[2]{RESET}  Update username only")
        print(f"    {BGREEN}›{RESET}  {BOLD}[3]{RESET}  Update token only")
        print(f"    {BGREEN}›{RESET}  {BOLD}[4]{RESET}  Test token against GitHub API")
        print(f"    {BGREEN}›{RESET}  {BOLD}[5]{RESET}  Apply credentials to git remote now")
        print(f"    {BRED}›{RESET}  {BOLD}[6]{RESET}  {RED}Clear all saved credentials{RESET}")
        print(f"    {BBLACK}‹{RESET}  {BBLACK}[0]{RESET}  {DIM}Back to main menu{RESET}")
        blank()

        choice = prompt("Select option").strip()

        if choice == "1":
            _cred_save_both(cfg)
        elif choice == "2":
            _cred_update_username(cfg)
        elif choice == "3":
            _cred_update_token(cfg)
        elif choice == "4":
            _cred_test_token(cfg)
            press_enter()
        elif choice == "5":
            _cred_apply(cfg)
            press_enter()
        elif choice == "6":
            _cred_clear()
            press_enter()
        elif choice == "0":
            break
        else:
            warn("Invalid option.")
            press_enter()

def _cred_save_both(cfg: dict):
    blank()
    section("Save Credentials")
    info("Token is stored locally with chmod 600 (owner read/write only).")
    info("Generate a PAT at: https://github.com/settings/tokens")
    info("Required scope   : repo  (full control of repositories)")
    blank()

    new_user = prompt("GitHub username", cfg.get("github_username", ""))
    new_tok  = prompt_secret("GitHub Personal Access Token (PAT) [input hidden]")

    if not new_user or not new_tok:
        warn("Both username and token are required. Cancelled.")
        press_enter()
        return

    cfg["github_username"] = new_user
    cfg["github_token"]    = new_tok
    _save_config(cfg)
    apply_git_credentials()
    blank()
    ok(f"Credentials saved for {BOLD}{BCYAN}{new_user}{RESET}.")
    ok("Remote URL updated — no more username/password prompts.")
    logger.info(f"Credentials saved for user: {new_user}")
    press_enter()

def _cred_update_username(cfg: dict):
    blank()
    section("Update Username")
    new_user = prompt("GitHub username", cfg.get("github_username", ""))
    if not new_user:
        warn("No input — username unchanged.")
        press_enter()
        return
    cfg["github_username"] = new_user
    _save_config(cfg)
    apply_git_credentials()
    ok(f"Username updated to: {BOLD}{BCYAN}{new_user}{RESET}")
    logger.info(f"Username updated: {new_user}")
    press_enter()

def _cred_update_token(cfg: dict):
    blank()
    section("Update Token")
    info("Generate a PAT at: https://github.com/settings/tokens")
    info("Required scope   : repo  (full control of repositories)")
    blank()
    new_tok = prompt_secret("New GitHub Personal Access Token (PAT) [input hidden]")
    if not new_tok:
        warn("No input — token unchanged.")
        press_enter()
        return
    cfg["github_token"] = new_tok
    _save_config(cfg)
    apply_git_credentials()
    ok("Token saved and applied to remote URL.")
    logger.info("GitHub token updated.")
    press_enter()

def _cred_test_token(cfg: dict):
    blank()
    section("Test Token")

    if not curl_available():
        err("curl is not installed or not in PATH. Cannot test token.")
        return

    token = (
        cfg.get("github_token")
        or os.environ.get("GITHUB_TOKEN")
        or os.environ.get("GH_TOKEN")
    )
    if not token:
        err("No token available. Save credentials first (option 1 or 3).")
        return

    step("Calling GitHub API  →  GET /user …")
    resp_file = "/tmp/_hivoid_panel_test_resp.json"
    code, status, _ = run(
        f'curl -s -o "{resp_file}" -w "%{{http_code}}" '
        f'-H "Authorization: token {token}" '
        f'https://api.github.com/user'
    )
    if code != 0:
        err("curl command failed. Check your internet connection.")
        logger.error("Token test: curl command failed.")
        return

    status = status.strip()
    logger.debug(f"Token test HTTP status: {status}")

    if status == "200":
        try:
            with open(resp_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            login = data.get("login", "?")
            name  = data.get("name") or ""
            email = data.get("email") or ""
            plan  = (data.get("plan") or {}).get("name", "")
            blank()
            ok(f"Token is {BOLD}{BGREEN}VALID{RESET}")
            info(f"Login  : {BOLD}{BCYAN}{login}{RESET}" + (f"  ({name})" if name else ""))
            if email:
                info(f"Email  : {email}")
            if plan:
                info(f"Plan   : {plan}")
            logger.info(f"Token test successful for login: {login}")
        except Exception as ex:
            ok("Token is valid (HTTP 200).")
            logger.warning(f"Token test: could not parse response JSON: {ex}")
    elif status == "401":
        blank()
        err(f"Token is {BOLD}{BRED}INVALID{RESET} or {BOLD}EXPIRED{RESET}  (HTTP 401).")
        info("Generate a new PAT at: https://github.com/settings/tokens")
        logger.warning("Token test: token invalid or expired (HTTP 401).")
    else:
        blank()
        err(f"Unexpected HTTP response: {status}")
        logger.error(f"Token test: unexpected HTTP status {status}.")

def _cred_apply(cfg: dict):
    blank()
    section("Apply Credentials to Remote")
    username = cfg.get("github_username", "")
    token    = cfg.get("github_token", "")
    if not username or not token:
        err("Both username and token must be saved first.")
        return
    apply_git_credentials()
    ok("Credentials embedded in remote URL.")
    ok("Git push/pull will no longer prompt for username/password.")

def _cred_clear():
    blank()
    section("Clear Credentials")
    if not confirm(f"{RED}Delete all saved credentials permanently?{RESET}", "n"):
        warn("Cancelled.")
        return
    try:
        if os.path.isfile(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        ok("Config file deleted.")
        logger.info("Credentials config file deleted.")
    except Exception as ex:
        err(f"Could not delete config: {ex}")
        logger.error(f"_cred_clear: {ex}")
        return
    if is_git_repo():
        run(f'git remote set-url origin "{REPO_URL}"')
        ok("Remote URL reset (credentials removed).")
    ok("All credentials cleared.")

# ──────────────────────────────────────────────────────────────
# MODULE: GITHUB CONNECTION SETUP
# ──────────────────────────────────────────────────────────────

def setup_github_connection():
    banner()
    section("GitHub Connection Setup")
    info(f"Target repository: {BOLD}{BCYAN}{REPO_URL}{RESET}")

    if is_git_repo():
        remote = get_remote_url()
        if remote:
            ok(f"Already a Git repo. Remote origin: {BCYAN}{remote}{RESET}")
            if remote.rstrip("/").split("@")[-1] != REPO_URL.lstrip("https://"):
                if not re.search(rf"{REPO_OWNER}/{REPO_NAME}", remote):
                    warn(f"Remote differs from expected: {REPO_URL}")
        else:
            warn("Git repo found but no remote origin set.")
            _add_remote()
        press_enter()
        return

    info("No Git repository detected. Initialising…")
    blank()

    step("Running git init…")
    code, out, er = run("git init")
    if code != 0:
        err(f"git init failed: {er}")
        logger.error(f"git init failed: {er}")
        press_enter()
        return
    ok("git init complete.")

    step("Setting default branch to main…")
    run("git symbolic-ref HEAD refs/heads/main")
    ok("Default branch set to main.")

    _add_remote()

    step("Verifying remote connection…")
    code, out, er = run(f"git ls-remote --heads {REPO_URL}")
    if code == 0:
        ok("Remote connection verified.")
        logger.info("Remote connection verified.")
    else:
        warn(f"Could not reach remote (may be private or offline): {er}")
        logger.warning(f"Could not reach remote: {er}")

    press_enter()

def _add_remote():
    step(f"Adding remote origin: {REPO_URL}")
    run("git remote remove origin")
    code, _, er = run(f"git remote add origin {REPO_URL}")
    if code != 0:
        err(f"Failed to add remote: {er}")
        logger.error(f"_add_remote failed: {er}")
    else:
        ok("Remote origin added.")
        logger.info(f"Remote origin set to {REPO_URL}")

# ──────────────────────────────────────────────────────────────
# MODULE: UPLOAD PROJECT (push + tag)
# ──────────────────────────────────────────────────────────────

def remote_branch_exists(branch="main") -> bool:
    """Return True if origin/branch exists on the remote."""
    code, out, _ = run(f"git ls-remote --heads origin {branch}")
    return code == 0 and bool(out.strip())

def ensure_on_main() -> bool:
    """
    Make sure we are on branch 'main'.
    Returns True on success.
    """
    branch = current_branch()
    if branch == "main":
        return True
    if branch in ("HEAD", "master"):
        step(f"Renaming branch '{branch}' → 'main'…")
        code, _, er = run("git checkout -b main 2>/dev/null || git branch -m main")
        if code != 0:
            code, _, er = run("git branch -m main")
        if code != 0:
            err(f"Could not switch to main: {er}")
            logger.error(f"ensure_on_main branch rename failed: {er}")
            return False
        ok("Now on branch: main")
        return True
    warn(f"Current branch is '{branch}', not 'main'.")
    if confirm("Switch to main before pushing?", "y"):
        code, _, er = run("git checkout main 2>/dev/null || git checkout -b main")
        if code != 0:
            err(f"Could not switch to main: {er}")
            logger.error(f"ensure_on_main checkout failed: {er}")
            return False
        ok("Switched to main.")
    return True

def upload_project():
    banner()
    section("Upload Project → Push & Tag Release")

    if not is_git_repo():
        err("Not a Git repository. Run 'GitHub Connection Setup' first.")
        press_enter()
        return

    branch = current_branch()
    info(f"Current branch: {BOLD}{BCYAN}{branch}{RESET}")
    info(f"Target remote : {BOLD}{BCYAN}{REPO_URL}{RESET}")

    blank()
    commit_msg = prompt("Commit message", "chore: update hivoid-panel files")
    blank()

    version_tag = prompt("Release version tag (e.g. v1.0.0)")
    if not validate_semver(version_tag):
        err(f"Invalid version format: '{version_tag}'. Must be vX.Y.Z (e.g. v1.2.3)")
        press_enter()
        return

    # Check if tag exists locally
    force_tag = False
    if version_tag in get_tags():
        warn(f"Tag '{version_tag}' already exists locally.")
        if confirm(f"Do you want to force overwrite and re-upload {BOLD}{version_tag}{RESET}?", "n"):
            force_tag = True
        else:
            warn("Upload cancelled.")
            press_enter()
            return

    remote_exists = remote_branch_exists("main")

    blank()
    hr()
    info("Preparing to:")
    if remote_exists:
        print(f"      {BBLUE}·{RESET} Pull latest from {BOLD}main{RESET}")
    else:
        print(f"      {BYELLOW}·{RESET} {YELLOW}First push — remote main does not exist yet (skip pull){RESET}")
    print(f"      {BBLUE}·{RESET} Commit all changes: {ITALIC}\"{commit_msg}\"{RESET}")
    print(f"      {BBLUE}·{RESET} Push to {BOLD}main{RESET}")
    if force_tag:
        print(f"      {BYELLOW}·{RESET} {BYELLOW}Force overwrite tag {BOLD}{version_tag}{RESET}")
    else:
        print(f"      {BBLUE}·{RESET} Create release tag {BOLD}{BGREEN}{version_tag}{RESET}")
    print(f"      {BBLUE}·{RESET} Push tag to GitHub")
    blank()

    if not confirm("Proceed with upload?", "n"):
        warn("Upload cancelled.")
        press_enter()
        return

    blank()
    section("Executing Upload")

    if not ensure_on_main():
        press_enter()
        return

    apply_git_credentials()

    step("Staging all changes (git add -A)…")
    code, _, er = run("git add -A")
    if code != 0:
        err(f"git add failed: {er}")
        logger.error(f"git add -A failed: {er}")
        press_enter()
        return
    ok("Files staged.")

    _, status, _ = run("git status --porcelain")
    if not status:
        code_log, _, _ = run("git log --oneline -1")
        if code_log != 0:
            err("Nothing to commit and no commits exist yet. Add files first.")
            press_enter()
            return
        warn("Nothing to commit — working tree clean.")
        info("Proceeding with push and tag only.")
    else:
        step(f"Committing: \"{commit_msg}\"…")
        code, _, er = run(f'git commit -m "{commit_msg}"')
        if code != 0:
            err(f"git commit failed: {er}")
            logger.error(f"git commit failed: {er}")
            press_enter()
            return
        ok("Commit created.")

    if remote_exists:
        step("Pulling latest from main (--rebase)…")
        code = run_live("git pull --rebase origin main")
        if code != 0:
            err("git pull --rebase failed. Resolve conflicts and retry.")
            logger.error("git pull --rebase failed.")
            press_enter()
            return
        ok("Pulled latest changes.")
    else:
        info("Skipping pull — remote main branch does not exist yet (first push).")

    step("Pushing to main…")
    if remote_exists:
        code = run_live("git push origin main")
    else:
        code = run_live("git push -u origin main")
    if code != 0:
        err("git push failed.")
        logger.error("git push to main failed.")
        press_enter()
        return
    ok("Pushed to main.")

    tag_msg = f"Release {version_tag} — {datetime.now().strftime('%Y-%m-%d')}"
    step(f"Creating annotated tag {BOLD}{version_tag}{RESET}…")
    tag_cmd = f'git tag -a "{version_tag}" -m "{tag_msg}"'
    if force_tag:
        tag_cmd = f'git tag -f -a "{version_tag}" -m "{tag_msg}"'

    code, _, er = run(tag_cmd)
    if code != 0:
        err(f"git tag failed: {er}")
        logger.error(f"git tag failed: {er}")
        press_enter()
        return
    ok(f"Tag {version_tag} created.")

    step(f"Pushing tag {version_tag} to GitHub…")
    push_tag_cmd = f"git push origin {version_tag}"
    if force_tag:
        push_tag_cmd = f"git push -f origin {version_tag}"
    code = run_live(push_tag_cmd)

    if code != 0:
        err("Failed to push tag.")
        logger.error(f"Failed to push tag {version_tag}.")
        press_enter()
        return
    ok(f"Tag {version_tag} pushed to GitHub.")
    logger.info(f"Upload complete: branch pushed and tag {version_tag} created.")

    blank()
    hr("═", BGREEN)
    print(f"\n  {BGREEN}{BOLD}🎉 Upload complete!{RESET}")
    print(f"  {DIM}Branch pushed and release tag {BOLD}{version_tag}{RESET}{DIM} created successfully.{RESET}\n")
    hr("═", BGREEN)
    press_enter()

# ──────────────────────────────────────────────────────────────
# MODULE: FETCH LATEST RELEASE FROM HIVOID-PANEL
# ──────────────────────────────────────────────────────────────

def _github_api_get(path: str, token: str) -> tuple:
    """
    Perform a GET request to the GitHub API.
    Returns (http_status_str, parsed_dict_or_list | None).
    """
    if not curl_available():
        err("curl is not installed or not in PATH.")
        return "", None

    resp_file = "/tmp/_hivoid_panel_api_resp.json"
    cmd = (
        f'curl -s -o "{resp_file}" -w "%{{http_code}}" '
        f'-H "Authorization: token {token}" '
        f'-H "Accept: application/vnd.github+json" '
        f'"https://api.github.com{path}"'
    )
    code, status, _ = run(cmd)
    if code != 0:
        logger.error(f"_github_api_get curl failed for path {path}")
        return "", None

    status = status.strip()
    try:
        with open(resp_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as ex:
        logger.warning(f"_github_api_get: JSON parse error: {ex}")
        return status, None

    return status, data

def fetch_latest_release():
    """
    Fetch and display the latest release from hivoid-panel, including
    all attached assets.
    """
    banner()
    section(f"Latest Release  ·  {REPO_OWNER}/{REPO_NAME}")

    token = get_github_token()
    if not token:
        err("No GitHub token available. Cannot query the API.")
        press_enter()
        return

    step(f"Fetching latest release from {REPO_OWNER}/{REPO_NAME}…")
    status, data = _github_api_get(
        f"/repos/{REPO_OWNER}/{REPO_NAME}/releases/latest", token
    )

    if not status:
        err("Request failed. Check your internet connection.")
        press_enter()
        return

    if status == "404":
        warn("No releases found for this repository yet.")
        logger.info("fetch_latest_release: 404 — no releases found.")
        press_enter()
        return

    if status != "200":
        err(f"GitHub API returned HTTP {status}.")
        logger.error(f"fetch_latest_release: unexpected HTTP {status}.")
        press_enter()
        return

    if not data or not isinstance(data, dict):
        err("Unexpected API response format.")
        press_enter()
        return

    # ── Display release metadata ───────────────────────────────
    tag        = data.get("tag_name", "?")
    name       = data.get("name") or tag
    published  = data.get("published_at", "?")[:10]
    prerelease = data.get("prerelease", False)
    body       = (data.get("body") or "").strip()
    html_url   = data.get("html_url", "")
    assets     = data.get("assets", [])
    author     = (data.get("author") or {}).get("login", "?")

    blank()
    hr()
    ok(f"Tag        : {BOLD}{BGREEN}{tag}{RESET}")
    info(f"Name       : {BOLD}{name}{RESET}")
    info(f"Published  : {published}")
    info(f"Author     : {author}")
    if prerelease:
        warn("This is a PRE-RELEASE.")
    info(f"URL        : {DIM}{html_url}{RESET}")

    if body:
        blank()
        section("Release Notes")
        for line in body.splitlines()[:20]:
            print(f"  {DIM}{BBLACK}{line}{RESET}")
        if len(body.splitlines()) > 20:
            info(f"… ({len(body.splitlines()) - 20} more lines — see full notes online)")

    blank()
    section("Release Assets")
    if not assets:
        info("No assets attached to this release.")
    else:
        info(f"Found {BOLD}{len(assets)}{RESET} asset(s):")
        blank()
        for asset in assets:
            aname      = asset.get("name", "unknown")
            asize      = asset.get("size", 0)
            adownloads = asset.get("download_count", 0)
            aurl       = asset.get("browser_download_url", "")
            print(
                f"    {BGREEN}✦{RESET}  {BOLD}{aname:<50}{RESET}"
                f"  {DIM}{_format_size(asize):>9}{RESET}"
                f"  {DIM}{adownloads} downloads{RESET}"
            )
            print(f"       {DIM}{BBLACK}{aurl}{RESET}")
        blank()

    logger.info(f"Fetched latest release: {tag} ({len(assets)} assets).")
    press_enter()

def fetch_all_releases():
    """
    Fetch and display a list of all releases from hivoid-panel.
    """
    banner()
    section(f"All Releases  ·  {REPO_OWNER}/{REPO_NAME}")

    token = get_github_token()
    if not token:
        err("No GitHub token available. Cannot query the API.")
        press_enter()
        return

    step(f"Fetching releases from {REPO_OWNER}/{REPO_NAME}…")
    status, data = _github_api_get(
        f"/repos/{REPO_OWNER}/{REPO_NAME}/releases?per_page=30", token
    )

    if not status:
        err("Request failed. Check your internet connection.")
        press_enter()
        return

    if status == "404":
        warn("Repository not found or no releases exist.")
        press_enter()
        return

    if status != "200":
        err(f"GitHub API returned HTTP {status}.")
        logger.error(f"fetch_all_releases: unexpected HTTP {status}.")
        press_enter()
        return

    if not data or not isinstance(data, list):
        warn("No releases found or unexpected API response format.")
        press_enter()
        return

    blank()
    info(f"Found {BOLD}{len(data)}{RESET} release(s):")
    blank()

    for rel in data:
        tag        = rel.get("tag_name", "?")
        name       = rel.get("name") or tag
        published  = rel.get("published_at", "?")[:10]
        prerelease = rel.get("prerelease", False)
        n_assets   = len(rel.get("assets", []))
        pre_label  = f"  {BYELLOW}[pre]{RESET}" if prerelease else ""
        print(
            f"    {BGREEN}✦{RESET}  {BOLD}{BGREEN}{tag:<14}{RESET}"
            f"  {name:<40}"
            f"  {DIM}{published}{RESET}"
            f"  {DIM}{n_assets} asset(s){RESET}"
            f"{pre_label}"
        )

    logger.info(f"Fetched {len(data)} releases from {REPO_OWNER}/{REPO_NAME}.")
    press_enter()

# ──────────────────────────────────────────────────────────────
# MODULE: CREATE GITHUB RELEASE
# ──────────────────────────────────────────────────────────────

def _format_size(n: int) -> str:
    """Human-readable file size."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"

def _collect_assets() -> list:
    """
    Ask the user whether they have release asset files.
    Returns a list of absolute file paths, or [] if none.
    """
    blank()
    hr()
    info("Release Assets")
    print(f"  {DIM}Do you have compiled binaries or zip files to attach to this release?{RESET}")
    print(f"  {DIM}(e.g. a dist/ folder with .zip or .tar.gz files){RESET}")
    blank()

    if not confirm("Attach asset files to this release?", "n"):
        info("No assets will be attached.")
        return []

    asset_dir = prompt("Path to assets folder (e.g. dist/  or  /home/user/project/dist)")
    asset_dir = os.path.expanduser(asset_dir.strip())

    if not asset_dir:
        warn("No path entered. Skipping assets.")
        return []

    if not os.path.isdir(asset_dir):
        err(f"Directory not found: {asset_dir}")
        return []

    try:
        entries = sorted(os.listdir(asset_dir))
    except Exception as ex:
        err(f"Could not read directory: {ex}")
        logger.error(f"_collect_assets listdir failed: {ex}")
        return []

    files = [os.path.join(asset_dir, name) for name in entries if os.path.isfile(os.path.join(asset_dir, name))]

    if not files:
        warn(f"No files found in: {asset_dir}")
        return []

    blank()
    info(f"Found {BOLD}{len(files)}{RESET} file(s) in {BOLD}{asset_dir}{RESET}:")
    blank()
    total = 0
    for f in files:
        size = os.path.getsize(f)
        total += size
        name = os.path.basename(f)
        print(f"    {BGREEN}✦{RESET}  {BOLD}{name:<50}{RESET}  {DIM}{_format_size(size):>9}{RESET}")
    blank()
    print(f"    {DIM}Total: {_format_size(total)}{RESET}")
    blank()

    if not confirm(f"Upload all {len(files)} file(s) as release assets?", "y"):
        warn("Asset upload skipped.")
        return []

    return files

def create_github_release():
    banner()
    section("Create GitHub Release")

    if not is_git_repo():
        err("Not a Git repository. Run 'GitHub Connection Setup' first.")
        press_enter()
        return

    blank()
    version_tag = prompt("Version tag (e.g. v1.0.0)")
    if not validate_semver(version_tag):
        err(f"Invalid version format: '{version_tag}'. Must be vX.Y.Z")
        press_enter()
        return

    blank()
    md_path = prompt("Path to release notes Markdown file (.md)")
    md_path = os.path.expanduser(md_path.strip())

    if not os.path.isfile(md_path):
        err(f"File not found: {md_path}")
        press_enter()
        return

    if not md_path.lower().endswith(".md"):
        warn("File does not have a .md extension. Proceeding anyway…")

    try:
        with open(md_path, "r", encoding="utf-8") as f:
            release_notes = f.read()
    except Exception as ex:
        err(f"Could not read file: {ex}")
        logger.error(f"create_github_release: could not read notes file: {ex}")
        press_enter()
        return

    if not release_notes.strip():
        err("Release notes file is empty.")
        press_enter()
        return

    asset_files = _collect_assets()

    blank()
    hr()
    info(f"Repository   : {BOLD}{BCYAN}{REPO_OWNER}/{REPO_NAME}{RESET}")
    info(f"Release tag  : {BOLD}{BGREEN}{version_tag}{RESET}")
    info(f"Notes file   : {BOLD}{md_path}{RESET}")
    info(f"Notes length : {len(release_notes)} characters")
    if asset_files:
        info(f"Assets       : {BOLD}{BGREEN}{len(asset_files)} file(s){RESET}")
        for f in asset_files:
            print(f"               {DIM}{os.path.basename(f)}{RESET}")
    else:
        info(f"Assets       : {DIM}none{RESET}")
    blank()
    print(f"  {DIM}── Notes preview (first 5 lines) ──────────────{RESET}")
    for line in release_notes.splitlines()[:5]:
        print(f"  {DIM}{BBLACK}{line}{RESET}")
    print(f"  {DIM}───────────────────────────────────────────────{RESET}")
    blank()

    if not confirm(f"Create GitHub release {BOLD}{version_tag}{RESET}?", "n"):
        warn("Release creation cancelled.")
        press_enter()
        return

    blank()
    section("Executing Release Creation")

    existing_tags = get_tags()
    if version_tag in existing_tags:
        warn(f"Tag {version_tag} already exists locally.")
        if not confirm(f"Use existing tag {BOLD}{version_tag}{RESET} and continue?", "n"):
            warn("Release creation cancelled.")
            press_enter()
            return
        ok(f"Using existing tag {version_tag}.")
    else:
        step(f"Creating annotated tag {BOLD}{version_tag}{RESET}…")
        tag_msg = f"Release {version_tag}"
        code, _, er = run(f'git tag -a "{version_tag}" -m "{tag_msg}"')
        if code != 0:
            err(f"git tag failed: {er}")
            logger.error(f"git tag failed: {er}")
            press_enter()
            return
        ok(f"Tag {version_tag} created.")

    step(f"Pushing tag {version_tag} to remote…")
    code = run_live(f"git push origin {version_tag}")
    if code != 0:
        err("Failed to push tag to remote.")
        logger.error(f"Failed to push tag {version_tag}.")
        press_enter()
        return
    ok("Tag pushed to GitHub.")

    if gh_cli_available():
        _create_release_gh_cli(version_tag, release_notes, asset_files)
    else:
        _create_release_api(version_tag, release_notes, asset_files)

    press_enter()

def _create_release_gh_cli(version_tag: str, notes: str, asset_files: list):
    """Create release (+ upload assets) using GitHub CLI."""
    step("Creating GitHub release via GitHub CLI (gh)…")
    tmp = "/tmp/_hivoid_panel_release_notes.md"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(notes)
    except Exception as ex:
        err(f"Could not write temp file: {ex}")
        logger.error(f"_create_release_gh_cli temp write failed: {ex}")
        return

    asset_args = ""
    if asset_files:
        asset_args = " " + " ".join(f'"{f}"' for f in asset_files)

    cmd = (
        f'gh release create "{version_tag}" '
        f'--repo "{REPO_URL}" '
        f'--title "Release {version_tag}" '
        f'--notes-file "{tmp}"'
        f'{asset_args}'
    )
    code = run_live(cmd)
    if code == 0:
        ok(f"GitHub release {version_tag} created via gh CLI.")
        if asset_files:
            ok(f"{len(asset_files)} asset file(s) uploaded.")
        logger.info(f"Release {version_tag} created via gh CLI.")
    else:
        err("gh CLI release creation failed. Try authenticating: gh auth login")
        logger.error(f"gh CLI release creation failed for {version_tag}.")

def _create_release_api(version_tag: str, notes: str, asset_files: list):
    """Create release using GitHub API via curl, then upload assets."""
    step("GitHub CLI not found. Attempting via GitHub API (curl)…")

    if not curl_available():
        err("curl is not installed or not in PATH. Cannot create release via API.")
        return

    token = get_github_token()
    if not token:
        err("No token provided. Cannot create release via API.")
        return

    payload = {
        "tag_name": version_tag,
        "name": f"Release {version_tag}",
        "body": notes,
        "draft": False,
        "prerelease": False,
    }
    tmp_payload = "/tmp/_hivoid_panel_payload.json"
    try:
        with open(tmp_payload, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except Exception as ex:
        err(f"Could not write payload file: {ex}")
        logger.error(f"_create_release_api payload write failed: {ex}")
        return

    api_url   = f"{API_BASE}/releases"
    resp_file = "/tmp/_hivoid_panel_api_resp.json"
    cmd = (
        f'curl -s -o "{resp_file}" -w "%{{http_code}}" '
        f'-X POST "{api_url}" '
        f'-H "Authorization: token {token}" '
        f'-H "Content-Type: application/json" '
        f'-d @"{tmp_payload}"'
    )
    code, http_status, _ = run(cmd)
    if code != 0:
        err("curl command failed. Ensure curl is installed.")
        logger.error("_create_release_api: curl POST failed.")
        return

    http_status = http_status.strip()
    logger.debug(f"_create_release_api: HTTP {http_status}")

    if http_status != "201":
        try:
            with open(resp_file, encoding="utf-8") as f:
                resp = f.read()
        except Exception:
            resp = "(no response)"
        err(f"API responded with HTTP {http_status}. Response: {resp[:300]}")
        logger.error(f"_create_release_api: HTTP {http_status}. Body: {resp[:300]}")
        return

    ok(f"GitHub release {version_tag} created via API.")
    logger.info(f"Release {version_tag} created via API.")

    if not asset_files:
        return

    try:
        with open(resp_file, "r", encoding="utf-8") as f:
            resp_json = json.load(f)
        upload_url = resp_json.get("upload_url", "")
        upload_url = upload_url.split("{")[0]
    except Exception as ex:
        err(f"Could not parse upload_url from API response. Assets not uploaded.")
        logger.error(f"_create_release_api: upload_url parse failed: {ex}")
        return

    if not upload_url:
        err("No upload_url in API response. Assets not uploaded.")
        return

    blank()
    section("Uploading Release Assets")
    for fpath in asset_files:
        fname = os.path.basename(fpath)
        step(f"Uploading {BOLD}{fname}{RESET}…")
        upload_resp = "/tmp/_hivoid_panel_upload_resp.json"
        upload_cmd = (
            f'curl -s -o "{upload_resp}" -w "%{{http_code}}" '
            f'-X POST "{upload_url}?name={fname}" '
            f'-H "Authorization: token {token}" '
            f'-H "Content-Type: application/octet-stream" '
            f'--data-binary @"{fpath}"'
        )
        ucode, ustatus, _ = run(upload_cmd)
        ustatus = ustatus.strip()
        if ucode != 0:
            err(f"curl failed while uploading {fname}")
            logger.error(f"Asset upload curl failed for {fname}.")
        elif ustatus == "201":
            size = _format_size(os.path.getsize(fpath))
            ok(f"{fname}  {DIM}({size}){RESET}")
            logger.info(f"Asset uploaded: {fname} ({size}).")
        else:
            try:
                with open(upload_resp, encoding="utf-8") as f:
                    ur = f.read()
            except Exception:
                ur = ""
            err(f"Upload failed for {fname} — HTTP {ustatus}. {ur[:200]}")
            logger.error(f"Asset upload failed: {fname} HTTP {ustatus}. {ur[:200]}")

# ──────────────────────────────────────────────────────────────
# MODULE: BRANCH MANAGEMENT
# ──────────────────────────────────────────────────────────────

def branch_management():
    while True:
        banner()
        section("Branch Management")

        branch = current_branch()
        info(f"Current branch: {BOLD}{BCYAN}{branch}{RESET}")
        blank()

        options = [
            ("1", "Create new branch"),
            ("2", "Switch branch"),
            ("3", "Show repository status"),
            ("4", "List all branches"),
            ("0", "Back to main menu"),
        ]
        for key, label in options:
            marker = f"{BGREEN}›{RESET}" if key != "0" else f"{BBLACK}‹{RESET}"
            print(f"    {marker}  {BOLD}[{key}]{RESET}  {label}")
        blank()

        choice = prompt("Select option").strip()

        if choice == "1":
            _create_branch()
        elif choice == "2":
            _switch_branch()
        elif choice == "3":
            _show_status()
        elif choice == "4":
            _list_branches()
        elif choice == "0":
            break
        else:
            warn("Invalid option.")
            press_enter()

def _create_branch():
    blank()
    section("Create New Branch")
    name = prompt("New branch name")
    if not name:
        warn("No branch name entered.")
        press_enter()
        return
    if not re.match(r"^[a-zA-Z0-9_\-/\.]+$", name):
        err(f"Invalid branch name: '{name}'")
        press_enter()
        return
    if not confirm(f"Create and switch to branch {BOLD}{BCYAN}{name}{RESET}?"):
        warn("Cancelled.")
        press_enter()
        return
    code, _, er = run(f"git checkout -b {name}")
    if code == 0:
        ok(f"Switched to new branch: {name}")
        logger.info(f"Created and switched to branch: {name}")
    else:
        err(f"Failed to create branch: {er}")
        logger.error(f"_create_branch failed: {er}")
    press_enter()

def _switch_branch():
    blank()
    section("Switch Branch")
    _, out, _ = run("git branch --format='%(refname:short)'")
    branches = [b.strip("'") for b in out.splitlines() if b.strip()]
    if not branches:
        warn("No local branches found.")
        press_enter()
        return
    info("Available branches:")
    for i, b in enumerate(branches, 1):
        marker = f" {BGREEN}← current{RESET}" if b == current_branch() else ""
        print(f"    {DIM}[{i}]{RESET}  {b}{marker}")
    blank()
    choice = prompt("Branch name (or number)")
    if not choice:
        warn("Cancelled.")
        press_enter()
        return
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(branches):
            target = branches[idx]
        else:
            err("Number out of range.")
            press_enter()
            return
    else:
        target = choice

    if has_uncommitted_changes():
        warn("You have uncommitted changes. Stash or commit before switching.")
        if not confirm("Switch anyway?", "n"):
            press_enter()
            return

    code, _, er = run(f"git checkout {target}")
    if code == 0:
        ok(f"Switched to branch: {target}")
        logger.info(f"Switched to branch: {target}")
    else:
        err(f"Failed to switch: {er}")
        logger.error(f"_switch_branch failed: {er}")
    press_enter()

def _show_status():
    blank()
    section("Repository Status")
    run_live("git status")
    blank()
    section("Recent Commits (last 8)")
    run_live("git log --oneline --graph --decorate --color -8")
    blank()
    section("Tags")
    tags = get_tags()
    if tags:
        for t in tags[:10]:
            print(f"    {BGREEN}✦{RESET}  {t}")
        if len(tags) > 10:
            info(f"… and {len(tags) - 10} more tags.")
    else:
        info("No tags found.")
    press_enter()

def _list_branches():
    blank()
    section("All Branches")
    info("Local branches:")
    run_live("git branch -vv")
    blank()
    info("Remote branches:")
    run_live("git branch -r")
    press_enter()

# ──────────────────────────────────────────────────────────────
# MODULE: REPOSITORY STATUS
# ──────────────────────────────────────────────────────────────

def quick_status():
    banner()
    section("Repository Status Overview")

    if not is_git_repo():
        err("Not a Git repository.")
        press_enter()
        return

    branch = current_branch()
    remote = get_remote_url()
    tags   = get_tags()

    info(f"Repository : {BOLD}{BCYAN}{REPO_OWNER}/{REPO_NAME}{RESET}")
    info(f"Branch     : {BOLD}{BCYAN}{branch}{RESET}")
    info(f"Remote     : {BOLD}{BBLUE}{remote or 'none'}{RESET}")
    info(f"Tags       : {BOLD}{BGREEN}{', '.join(tags[:5]) if tags else 'none'}{RESET}")
    if has_uncommitted_changes():
        warn("Uncommitted changes detected.")
    else:
        ok("Working tree clean.")

    blank()
    section("git status")
    run_live("git status --short")
    blank()
    section("git log (last 5)")
    run_live("git log --oneline --graph --decorate --color -5")
    press_enter()

# ──────────────────────────────────────────────────────────────
# MAIN MENU
# ──────────────────────────────────────────────────────────────

MENU_OPTIONS = [
    ("1", "GitHub Connection Setup",  "Initialise repo & set remote origin",           setup_github_connection),
    ("2", "Upload Project",           "Commit · Push · Tag release",                    upload_project),
    ("3", "Create GitHub Release",    "Tag + release notes from Markdown file",         create_github_release),
    ("4", "Fetch Latest Release",     f"View latest release & assets from {REPO_NAME}", fetch_latest_release),
    ("5", "All Releases",             f"List all releases from {REPO_NAME}",            fetch_all_releases),
    ("6", "Branch Management",        "Create · Switch · List branches",                branch_management),
    ("7", "Repository Status",        "Quick overview of repo state",                   quick_status),
    ("8", "Credentials",              "Save GitHub username & token",                   manage_credentials),
    ("0", "Exit",                     "Quit the application",                           None),
]

def main_menu():
    validate_git_installed()
    apply_git_credentials()
    logger.info(f"HIVOID Panel Git Manager started. Target: {REPO_URL}")

    while True:
        banner()

        if is_git_repo():
            branch = current_branch()
            pill   = f"{BG_CYAN}{BLACK} ● {branch} {RESET}"
            dirty  = (
                f"  {BYELLOW}⚠ uncommitted changes{RESET}"
                if has_uncommitted_changes()
                else f"  {BGREEN}✔ clean{RESET}"
            )
        else:
            pill  = f"{BG_BLACK}{BWHITE}  not a git repo {RESET}"
            dirty = ""

        cfg = _load_config()
        if cfg.get("github_username") and cfg.get("github_token"):
            cred_pill = f"  {BGREEN}🔑 {cfg['github_username']}{RESET}"
        elif os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN"):
            cred_pill = f"  {BYELLOW}🔑 token via env{RESET}"
        else:
            cred_pill = f"  {BRED}🔑 no credentials saved{RESET}"

        print(f"  {pill}{dirty}{cred_pill}")
        blank()
        hr()
        blank()

        for key, label, desc, _ in MENU_OPTIONS:
            if key == "0":
                print(f"    {BBLACK}[0]{RESET}  {DIM}Exit{RESET}")
            else:
                num = f"{BOLD}{BWHITE}[{key}]{RESET}"
                lbl = f"{BOLD}{BWHITE}{label}{RESET}"
                dsc = f"{DIM}{BBLACK}{desc}{RESET}"
                print(f"    {num}  {lbl}  {dsc}")

        blank()
        hr()
        blank()

        choice = prompt("Select option").strip()

        matched = None
        for key, label, desc, fn in MENU_OPTIONS:
            if choice == key:
                matched = fn
                break

        if choice == "0":
            banner()
            logger.info("HIVOID Panel Git Manager exited by user.")
            print(f"\n  {BWHITE}{BOLD}Goodbye.{RESET}  {DIM}HIVOID Panel Git Manager closed.{RESET}\n")
            sys.exit(0)
        elif matched:
            matched()
        else:
            warn(f"Unknown option: '{choice}'")
            press_enter()

# ──────────────────────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print(f"\n\n  {DIM}Interrupted. Goodbye.{RESET}\n")
        logger.info("HIVOID Panel Git Manager interrupted by user.")
        sys.exit(0)
