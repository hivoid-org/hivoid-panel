# HiVoid Panel — Release Notes

## v2.0.0 — Core v2.0.0 Synchronization
> Released: 2026-06-09

This is a **major release** that fully synchronizes the HiVoid Panel with the **HiVoid-Core v2.0.0-stable** engine. It introduces a Hub-and-Node architecture, VoidReach transport layer support, live traffic accounting, and significant improvements to the multi-node management experience.

---

### Hub-and-Node WebSocket Infrastructure
- **New Dual Endpoint**: Added `/api/v1/nodes/ws` and `/api/v1/node/ws` WebSocket endpoints for remote nodes running in Hub/Slave mode to connect to the panel as a central hub.
- **Token Authentication**: Nodes authenticate using a `Bearer` token via the `Authorization` header or the `?token=` query parameter. The token is configurable via the `node_token` key in the core JSON config.
- **Instant SYNC on Connect**: Upon a successful node connection, the panel immediately pushes a `SYNC` command containing all enabled users and their full policy set — including `max_connections`, `max_ips`, `bandwidth_limit`, `data_limit`, `expire_at`, and dual compatibility fields (`is_active`, `expire_at_unix`).
- **Downstream Commands Supported**: `SYNC`, `CONFIG_UPDATE`, `SHOCK`, `REVOKE`, `TLS_INSTALL`, `GEODATA_INSTALL`.
- **Upstream Reports Handled**: `USAGE`, `REPORT`, `COMMAND_ACK`, `COMMAND_RESULT`, `INSTALL_RESULT`.

### Live Traffic Accounting via Remote Nodes
- **USAGE Processing**: When a remote node sends a `USAGE` report, the panel updates `bytes_in` and `bytes_out` in the database for each reported user (monotonically — only increases are applied).
- **Presence Tracking**: The `request_pool` field in `USAGE` messages is used to track active connections per user per node. When a client disconnects (`request_pool = 0`), the panel removes that session from the live dashboard.
- **Merged Active Sessions**: The `/api/protocol/active-sessions` endpoint now merges sessions from both local node connections and all remotely connected Hub nodes into a single view.

### Node Telemetry Dashboard
- **REPORT Handling**: Remote nodes periodically push system telemetry (`cpu_usage`, `ram_usage`, `process_cpu_usage`, `process_ram_usage_mb`, `uptime_seconds`, `active_connections`). This data is stored in-memory and is ready for future dashboard integration.

### VoidReach Transport Layer Support (Project VoidReach)
- **Config Generation**: If a `voidreach` configuration block is present in the panel's Core JSON settings, it is automatically injected into the generated `server.json` delivered to the core engine.
- **Client Subscription**: The `voidreach` block is also included in the generated client configuration (`client.json`) and subscription endpoint responses, so clients can use CDN/relay/direct/fronting transport modes out of the box.
- **Supported Modes**: `direct`, `fronting`, `relay`, `cdn`.

### Nested Config Schema (v2.0.0 Format)
- The panel now generates the new **nested `server.json`** format as the primary output:
  - `server.listen` (replaces flat `port`)
  - `security.cert_file` / `security.key_file` (replaces flat `cert` / `key`)
  - `features.hot_reload`, `features.connection_tracking`, `features.disconnect_expired`
- Old flat config format remains supported by the core engine for backward compatibility.

### Dependencies & Installer Updates
- Added `websockets` to `requirements.txt` and both `install.sh` and `install-dev.sh` pip install commands.
- All installer scripts are updated to ensure WebSocket support is available on fresh deployments.
